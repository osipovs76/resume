﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_1._1
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine(Properties.Resources.Hello + ", " + Properties.Settings.Default.Name + ".");
			Console.WriteLine("Чтобы программа попращалась нажмите Enter");
			Console.ReadLine();			
			Console.WriteLine(Properties.Resources.Bye + ", " + Properties.Settings.Default.Name + ".");
			Console.ReadLine();
		}
	}
}
