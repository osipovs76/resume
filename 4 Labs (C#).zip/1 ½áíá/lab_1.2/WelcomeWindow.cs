﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_1._2
{
    public partial class WelcomeWindow : Form
    {
        public WelcomeWindow()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           MessageBox.Show(Properties.Resources.Hello + ",  " + Properties.Settings.Default.Name + "!");
        }

        private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBox.Show(Properties.Resources.Bye + ",  " + Properties.Settings.Default.Name + "!");
        }

       
    }
}
