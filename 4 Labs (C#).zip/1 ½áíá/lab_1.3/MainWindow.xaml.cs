﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lab_1._3
{
    
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Load(object s, EventArgs e)
        {
           MessageBox.Show(Properties.Resources.Hello + ", " + Properties.Settings.Default.Name + "!");
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(Properties.Resources.Bye + ", " + Properties.Settings.Default.Name + "!");
        }

        private void WClosing(object s, System.ComponentModel.CancelEventArgs e)
        {
            
        }
    }
}
