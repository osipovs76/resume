﻿using System;
using System.Collections.Generic;

namespace OOPLAB2
{

    
    public class Clock 
    {
        public delegate void EnterClock(); //создаем делегат
        public event EnterClock SecondTick; //создаем событие
        public System.Windows.Forms.Timer My_Timer = new System.Windows.Forms.Timer(); //для таймера нужно создать экземпляр
        public DateTime CurrentTime; // переменная для настоящего времени
        public Dictionary<string, TimeSpan> DictionaryCities; //регионы
      
        public bool Stop;

        public Clock() 
        {      
              My_Timer.Tick += My_Timer_Tick;       //
              My_Timer.Enabled = true;              //отображения времени на форме   
              DictionaryCities = new Dictionary<string, TimeSpan> 
              {
                  {"Moscow", new TimeSpan(3,0,0)},
                  {"Vladivastok", new TimeSpan(10,0,0)}
              };

        }

        private void My_Timer_Tick(object sender, EventArgs e)  //метод для вычесление времени с компьютера
        {
            CurrentTime = DateTime.UtcNow; //приравниваем время по гринвичу
            SecondTick();                  
        }

        public DateTime LocalTime(string City) // метод для возвращения времени в соотвтсвтии с регионом
        {
            return CurrentTime + DictionaryCities[City]; // возвращает изменное текуее время 
        }
     
        public void StartAndStopClock()
        {
            if(!Stop)
            {
                Stop = true;
                My_Timer.Stop();
            }
            else
            {
                Stop = false;
                My_Timer.Start();
            }
        }
        
    }
}
