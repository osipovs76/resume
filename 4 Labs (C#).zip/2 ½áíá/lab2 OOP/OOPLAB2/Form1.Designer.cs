﻿namespace OOPLAB2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.London_TextBox = new System.Windows.Forms.TextBox();
            this.Vladivostock_TextBox = new System.Windows.Forms.TextBox();
            this.Moscow_TextBox = new System.Windows.Forms.TextBox();
            this.label_Moscow = new System.Windows.Forms.Label();
            this.label_london = new System.Windows.Forms.Label();
            this.label_vladivostok = new System.Windows.Forms.Label();
            this.button_lang = new System.Windows.Forms.Button();
            this.button_stop = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стопЗапускToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ctrlSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменаЯзыкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ctrlLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // London_TextBox
            // 
            resources.ApplyResources(this.London_TextBox, "London_TextBox");
            this.London_TextBox.Name = "London_TextBox";
            this.London_TextBox.TextChanged += new System.EventHandler(this.London_TextBox_TextChanged);
            // 
            // Vladivostock_TextBox
            // 
            resources.ApplyResources(this.Vladivostock_TextBox, "Vladivostock_TextBox");
            this.Vladivostock_TextBox.Name = "Vladivostock_TextBox";
            // 
            // Moscow_TextBox
            // 
            resources.ApplyResources(this.Moscow_TextBox, "Moscow_TextBox");
            this.Moscow_TextBox.Name = "Moscow_TextBox";
            this.Moscow_TextBox.TextChanged += new System.EventHandler(this.Moscow_TextBox_TextChanged);
            // 
            // label_Moscow
            // 
            resources.ApplyResources(this.label_Moscow, "label_Moscow");
            this.label_Moscow.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label_Moscow.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_Moscow.Name = "label_Moscow";
            this.label_Moscow.Click += new System.EventHandler(this.label_Moscow_Click);
            // 
            // label_london
            // 
            resources.ApplyResources(this.label_london, "label_london");
            this.label_london.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label_london.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_london.Name = "label_london";
            // 
            // label_vladivostok
            // 
            resources.ApplyResources(this.label_vladivostok, "label_vladivostok");
            this.label_vladivostok.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.label_vladivostok.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label_vladivostok.Name = "label_vladivostok";
            this.label_vladivostok.Click += new System.EventHandler(this.label3_Click);
            // 
            // button_lang
            // 
            resources.ApplyResources(this.button_lang, "button_lang");
            this.button_lang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.button_lang.ForeColor = System.Drawing.Color.White;
            this.button_lang.Name = "button_lang";
            this.button_lang.UseVisualStyleBackColor = false;
            this.button_lang.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_stop
            // 
            resources.ApplyResources(this.button_stop, "button_stop");
            this.button_stop.BackColor = System.Drawing.Color.LightBlue;
            this.button_stop.BackgroundImage = global::OOPLAB2.Properties.Resources.sta;
            this.button_stop.Name = "button_stop";
            this.button_stop.UseVisualStyleBackColor = false;
            this.button_stop.Click += new System.EventHandler(this.button2_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.менюToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.стопЗапускToolStripMenuItem,
            this.сменаЯзыкаToolStripMenuItem});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            resources.ApplyResources(this.менюToolStripMenuItem, "менюToolStripMenuItem");
            this.менюToolStripMenuItem.Click += new System.EventHandler(this.менюToolStripMenuItem_Click);
            // 
            // стопЗапускToolStripMenuItem
            // 
            this.стопЗапускToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctrlSToolStripMenuItem});
            this.стопЗапускToolStripMenuItem.Name = "стопЗапускToolStripMenuItem";
            resources.ApplyResources(this.стопЗапускToolStripMenuItem, "стопЗапускToolStripMenuItem");
            this.стопЗапускToolStripMenuItem.Click += new System.EventHandler(this.стопЗапускToolStripMenuItem_Click);
            // 
            // ctrlSToolStripMenuItem
            // 
            this.ctrlSToolStripMenuItem.Name = "ctrlSToolStripMenuItem";
            resources.ApplyResources(this.ctrlSToolStripMenuItem, "ctrlSToolStripMenuItem");
            this.ctrlSToolStripMenuItem.Click += new System.EventHandler(this.ctrlSToolStripMenuItem_Click);
            // 
            // сменаЯзыкаToolStripMenuItem
            // 
            this.сменаЯзыкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ctrlLToolStripMenuItem});
            this.сменаЯзыкаToolStripMenuItem.Name = "сменаЯзыкаToolStripMenuItem";
            resources.ApplyResources(this.сменаЯзыкаToolStripMenuItem, "сменаЯзыкаToolStripMenuItem");
            this.сменаЯзыкаToolStripMenuItem.Click += new System.EventHandler(this.сменаЯзыкаToolStripMenuItem_Click);
            // 
            // ctrlLToolStripMenuItem
            // 
            this.ctrlLToolStripMenuItem.Name = "ctrlLToolStripMenuItem";
            resources.ApplyResources(this.ctrlLToolStripMenuItem, "ctrlLToolStripMenuItem");
            this.ctrlLToolStripMenuItem.Click += new System.EventHandler(this.ctrlLToolStripMenuItem_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::OOPLAB2.Properties.Resources.city;
            this.Controls.Add(this.button_stop);
            this.Controls.Add(this.button_lang);
            this.Controls.Add(this.label_Moscow);
            this.Controls.Add(this.Moscow_TextBox);
            this.Controls.Add(this.Vladivostock_TextBox);
            this.Controls.Add(this.London_TextBox);
            this.Controls.Add(this.label_vladivostok);
            this.Controls.Add(this.label_london);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox London_TextBox;
        private System.Windows.Forms.TextBox Vladivostock_TextBox;
        private System.Windows.Forms.TextBox Moscow_TextBox;
        private System.Windows.Forms.Label label_Moscow;
        private System.Windows.Forms.Label label_london;
        private System.Windows.Forms.Label label_vladivostok;
        private System.Windows.Forms.Button button_lang;
        private System.Windows.Forms.Button button_stop;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem стопЗапускToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ctrlSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменаЯзыкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ctrlLToolStripMenuItem;
    }
}

