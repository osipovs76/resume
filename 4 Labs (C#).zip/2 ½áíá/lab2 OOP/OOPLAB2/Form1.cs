﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOPLAB2
{
    public partial class Form1 : Form
    {

        Clock clock;
        public Form1() 
        {
            System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language); //загрузка культур в ресурсы

            clock = new Clock();                 //обращение к часам
            clock.SecondTick += SecondTick;      //обработчик события 

            KeyPreview = true;                   //испоьзование клавиатур
            InitializeComponent();    
        
        }

        private void SecondTick() 
        {
            London_TextBox.Text = clock.CurrentTime.ToLongTimeString();                     //преображаем в стринг для текстбокса и отображаем 
            Moscow_TextBox.Text = clock.LocalTime("Moscow").ToLongTimeString();         
            Vladivostock_TextBox.Text = clock.LocalTime("Vladivastok").ToLongTimeString();
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            if (System.Threading.Thread.CurrentThread.CurrentUICulture.Name == "ru-RU")
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo("en-US");               
            }
            else
            {
                System.Threading.Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo("ru-RU");   
            }

            Application.Restart();  
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) //закрытие формы с сохранением культуры
        {
            Properties.Settings.Default.Language = System.Threading.Thread.CurrentThread.CurrentUICulture.Name; //смена языка реал тут
            Properties.Settings.Default.Save();
        }

        //привязки к кнопкам 
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.KeyCode == Keys.L && e.Alt)
            {
                button_lang.PerformClick();
            }
            if (e.KeyCode == Keys.S && e.Alt)
            {
                button_stop.PerformClick();
            }
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e) 
        {
            clock.StartAndStopClock();
           
        }
       
        private void стопЗапускToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button_stop.PerformClick();
        }

        private void сменаЯзыкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button_lang.PerformClick();
        }

        private void ctrlSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button_stop.PerformClick();
        }

        private void ctrlLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button_lang.PerformClick();
        }


        private void Form1_Load(object sender, EventArgs e) {}
        private void London_TextBox_TextChanged(object sender, EventArgs e) {}
        private void менюToolStripMenuItem_Click(object sender, EventArgs e){}
        private void Moscow_TextBox_TextChanged(object sender, EventArgs e) {}

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label_Moscow_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
