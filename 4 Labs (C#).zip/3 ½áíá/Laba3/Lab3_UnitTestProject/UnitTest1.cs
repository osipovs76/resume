﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Lab_3_v2.Model;

namespace Lab3_UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        private Firm f = new Firm("Russia", "14.06.2022",
                "neykBrah.nayk_7@gmail.ru", "VK",
                "212356", "Nor obl", "Pecher",
                "Novgorod", "vk.com");
        private Contact c = new Contact("20.04.2022",
            "25.04.2022", "sorand",
            "15.03.2022", new ContType());
        private SubFirm s = new SubFirm("Yan",
            "yanLEV.levanb@gmail.com", "Blizzard",
            "Yan", "021", new SbFirmType());

        [TestMethod]

        public void FirmAddCont()
        {
            f.AddCont(c);
        }

        [TestMethod]
        public void FirmAddContToSbFirm()
        {
            f.AddContToSbFirm(f.GetMain(), c);
        }

        [TestMethod]
        public void FirmAddFieldTrue()
        {
            f.AddField("1", "one");
            f.AddField("2", "two");
            f.AddField("3", "three");
            f.AddField("4", "four");
            Assert.IsTrue(f.AddField("5", "five"));
        }

        [TestMethod]
        public void FirmAddFieldFalse()
        {
            f.AddField("1", "one");
            f.AddField("2", "two");
            f.AddField("3", "three");
            f.AddField("4", "four");
            f.AddField("5", "five");
            Assert.IsFalse(f.AddField("6", "six"));
        }

        [TestMethod]
        public void FirmAddSbFirm()
        {
            f.AddSbFirm(s);
        }

        [TestMethod]
        public void FirmExistContactTrue()
        {
            f.AddCont(c);
            Assert.IsTrue(f.ExistContact(c));
        }

        [TestMethod]
        public void FirmExistContactFalse()
        {
            Assert.IsFalse(f.ExistContact(c));
        }

        [TestMethod]
        public void FirmGetFieldTrue()
        {
            f.AddField("1", "one");
            Assert.AreEqual(f.GetField("1"), "one");
        }

        [TestMethod]
        public void FirmGetFieldFalse()
        {
            Assert.AreEqual(f.GetField("1"), null);
        }

        [TestMethod]
        public void FirmGetMain()
        {
            SubFirm res = f.GetMain();
            Assert.AreEqual(res.Name, "Main");
        }

        [TestMethod]
        public void FirmRenameFieldTrue()
        {
            f.AddField("1", "one");
            f.RenameField("1", "2");
            Assert.AreEqual(f.GetField("2"), "one");
        }

        [TestMethod]
        public void FirmRenameFieldFalse()
        {
            Assert.IsFalse(f.RenameField("1", "2"));
        }

        [TestMethod]
        public void FirmSetFieldTrue()
        {
            f.AddField("1", "one");
            f.SetField("1", "two");
            Assert.AreEqual(f.GetField("1"), "two");
        }

        [TestMethod]
        public void FirmSetFieldFalse()
        {
            Assert.IsFalse(f.SetField("1", "two"));
        }

        [TestMethod]
        public void FirmCountryGet()
        {
            Assert.AreEqual(f.Country, "Russia");
        }

        [TestMethod]
        public void FirmCountrySet()
        {
            f.Country = "USA";
            Assert.AreEqual(f.Country, "USA");
        }

        [TestMethod]
        public void FirmDateInGet()
        {
            Assert.AreEqual(f.DateIn, "14.06.2022");
        }

        [TestMethod]
        public void FirmDateInSet()
        {
            f.DateIn = "07.04.2022";
            Assert.AreEqual(f.DateIn, "07.04.2022");
        }

        [TestMethod]
        public void FirmEmailGet()
        {
            Assert.AreEqual(f.Email, "neykBrah.nayk_7@gmail.ru");
        }

        [TestMethod]
        public void FirmEmailSet()
        {
            f.Email = "010101001011@gmail.com";
            Assert.AreEqual(f.Email, "010101001011@gmail.com");
        }

        [TestMethod]
        public void FirmNameGet()
        {
            Assert.AreEqual(f.Name, "VK");
        }

        [TestMethod]
        public void FirmNameSet()
        {
            f.Name = "Yan";
            Assert.AreEqual(f.Name, "Yan");
        }

        [TestMethod]
        public void FirmPostInxGet()
        {
            Assert.AreEqual(f.PostInx, "212356");
        }

        [TestMethod]
        public void FirmPostInxSet()
        {
            f.PostInx = "212356";
            Assert.AreEqual(f.PostInx, "212356");
        }

        [TestMethod]
        public void FirmRegionGet()
        {
            Assert.AreEqual(f.Region, "Nor obl");
        }

        [TestMethod]
        public void FirmRegionSet()
        {
            f.Region = "cold";
            Assert.AreEqual(f.Region, "cold");
        }

        [TestMethod]
        public void FirmSbFirmCount()
        {
            Assert.AreEqual(f.SbFirmsCount, 1);
        }

        [TestMethod]
        public void FirmStreetGet()
        {
            Assert.AreEqual(f.Street, "Pecher");
        }

        [TestMethod]
        public void FirmStreetSet()
        {
            f.Street = "Kazansk";
            Assert.AreEqual(f.Street, "Kazansk");
        }

        [TestMethod]
        public void FirmthisGet()
        {
            f.AddField("1", "one");
            Assert.AreEqual(f["1"], "one");
        }

        [TestMethod]
        public void FirmthisSet()
        {
            f.AddField("1", "one");
            f["1"] = "two";
            Assert.AreEqual(f["1"], "two");
        }

        [TestMethod]
        public void FirmTownGet()
        {
            Assert.AreEqual(f.Town, "Novgorod");
        }

        [TestMethod]
        public void FirmTownSet()
        {
            f.Town = "Gorod";
            Assert.AreEqual(f.Town, "Gorod");
        }

        [TestMethod]
        public void FirmWebGet()
        {
            Assert.AreEqual(f.Web, "vk.com");
        }

        [TestMethod]
        public void FirmWebSet()
        {
            f.Web = "mail.ru";
            Assert.AreEqual(f.Web, "mail.ru");
        }

    }
}
