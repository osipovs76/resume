﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    public class ContType //представляет информацию о типах подразделений
    {
        private string _name;
        private string _note;

        public string Name { get => _name; set => _name = value; }
        public string Note { get => _note; set => _note = value; }
    }
}
