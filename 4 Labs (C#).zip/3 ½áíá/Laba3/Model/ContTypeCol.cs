﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    class ContTypeCol
    {
        private List<ContType> _lst;

        public int Count { get => _lst.Count; }

        public ContType this[int index]
        {
            get { return _lst[index]; }
            set { _lst[index] = value; }
        }

        public void Add(ContType new_contact)
        {
            _lst.Add(new_contact);
        }

        // Методы
        public void Clear()
        {
            _lst.Clear();
        }

        public ContTypeCol()
        {
            _lst = new List<ContType>();
        }
    }
}
