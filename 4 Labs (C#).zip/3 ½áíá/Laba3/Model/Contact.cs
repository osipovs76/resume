﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    public class Contact
    {
        //поля содержащие информацию о контакте
        private string _beginDt;
        private string _dataInfo;
        private string _descr;
        private string _endDt;
        private ContType _tpy;

        public string BeginDt { get => _beginDt; set => _beginDt = value; }
        public ContType CntType {get => _tpy; set => _tpy=value;}
        public string DataInfo { get => _dataInfo; set => _dataInfo = value; }
        public string Descr { get => _descr; set => _descr = value; }
        public string EndDt { get => _endDt; set => _endDt = value; }

        public Contact Clone(Contact cont)
        {
            Contact clone = new Contact(cont.BeginDt, cont.DataInfo,
                cont.Descr, cont.EndDt, cont.CntType);
            return clone;
        }

        public Contact(string beginDt, string dataInfo, string descr, 
            string endDt, ContType type)
        {
            _beginDt = beginDt;
            _dataInfo = dataInfo;
            _descr = descr;
            _endDt = endDt;
            _tpy = type;
        }

        public static bool operator !=(Contact lhs, Contact rhs)
        {
            return !(lhs == rhs);
        }

        public static bool operator ==(Contact lhs, Contact rhs)
        {
            if (lhs.BeginDt == rhs.BeginDt &&
                lhs.CntType == rhs.CntType &&
                lhs.DataInfo == rhs.DataInfo &&
                lhs.Descr == rhs.Descr &&
                lhs.EndDt == rhs.EndDt)
                return true;

            else return false;
        }
    }
}
