﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    public class Firm
    {
        private string _country;
        private string _dateIn;
        private string _email;
        private string _name;
        private string _postInx;
        private string _region;
        private List<SubFirm> _sbFirms;
        private string _street;
        private string _town;
        //пользовательские значения
        private Dictionary<string, string> _usrFields;
        private string _web;

        //строго типизированные поля адресной информации
        public string Country { get => _country; set => _country = value; }
        public string DateIn { get => _dateIn; set => _dateIn = value; }
        public string Email { get => _email; set => _email = value; }
        public string Name { get => _name; set => _name = value; }
        public string PostInx { get => _postInx; set => _postInx = value; }
        public string Region { get => _region; set => _region = value; }
        public int SbFirmsCount => _sbFirms.Count;
        public string Street { get => _street; set => _street = value; }
        public string this[string index] { get => _usrFields[index]; set => _usrFields[index] = value; }
        public string Town { get => _town; set => _town = value; }
        public string Web { get => _web; set => _web = value; }

        public void AddCont(Contact c)
        { // 0 - Основное подразделение
            _sbFirms[0].AddCont(c);
        }

        public void AddContToSbFirm(SubFirm s, Contact c) { s.AddCont(c); }

        public bool AddField(string name, string value)
        {
            if (_usrFields.Count < 5)
            {
                _usrFields.Add(name, value);
                return true;
            }
            return false;
        }

        public void AddSbFirm(SubFirm s) { _sbFirms.Add(s); }

        public bool ExistContact(Contact c) { return _sbFirms[0].ExistContact(c); }

        public Firm(string country, string dateIn, string email, string name,
            string postInx, string region, string street, string town,
            string web, Dictionary<string, string> usrFields = null) // dict является необязательным
        {
            _country = country;
            _dateIn = dateIn;
            _email = email;
            _name = name;
            _postInx = postInx;
            _region = region;
            _sbFirms = new List<SubFirm>();
            _sbFirms.Add(new SubFirm("", "", "Main", "", "", new SbFirmType()));
            _street = street;
            _town = town;
            _usrFields = new Dictionary<string, string>(5);
            _web = web;
            if (usrFields != null && usrFields.Count > 5)
                throw new Exception("usrFields length should be <= 5");
        }

        public string GetField(string name)
        {
            if (_usrFields.ContainsKey(name))
                return _usrFields[name];
            return null;
        }

        public SubFirm GetMain()
        { // 0 - Основное подразделение
            return _sbFirms[0];
        }

        public bool RenameField(string name, string rename)
        {
            if (_usrFields.ContainsKey(name))
            {
                _usrFields.Add(rename, _usrFields[name]);
                _usrFields.Remove(name);
                return true;
            }
            return false;
        }

        public bool SetField(string name, string value)
        {
            if (_usrFields.ContainsKey(name))
            {
                _usrFields[name] = value;
                return true;
            }
            return false;
        }

    }
}
