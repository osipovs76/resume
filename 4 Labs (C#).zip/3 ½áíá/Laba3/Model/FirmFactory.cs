﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    class FirmFactory //создает экземпляры класса фирм правильной структуры
    {
        // Поля
        private Dictionary<string, string> _flds;
        private SubFirm _nameMain = new SubFirm("", "", "Main", "", "", new SbFirmType());

        // Методы
        public Firm Create(string country, string dateIn, string email, 
            string name, string postInx, string region, string street, string town, string web) {
            Firm new_firm = new Firm( country,  dateIn,  email, name,  postInx,  region,  street,  town,  web, _flds);
            return new_firm;
        }
        public void fldNames(Dictionary<string, string> new_flds)
        {
            _flds = new_flds;
        }
    }
}
