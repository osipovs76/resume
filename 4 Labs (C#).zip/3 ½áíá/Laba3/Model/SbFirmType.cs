﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    public class SbFirmType //представляет информацию о типах контактов 
    {
        private bool _isMain;
        private string _name;

        public bool IsMain { get => _isMain; set => _isMain = value; }
        public string Name { get => _name; set => _name = value; }

    }
}
