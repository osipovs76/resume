﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    class SubFirmCol : IEnumerator
    {
        // Поля
        private List<SbFirmType> _lst;

        // Свойства
        public int Count { get; private set; }

        public object Current
        {
            get { return _lst[Count]; }
        }

        public SbFirmType this[int index]
        {
            get { return _lst[index]; }
            set { _lst[index] = value; }
        }

        // Методы
        public void Add(SbFirmType new_type)
        {
            _lst.Add(new_type);
        }

        public void Dispose()
        {
            Count = -1;
        }

        public IEnumerator GetEnumerator()
        {
            return this;
        }

        public bool MoveNext()
        {
            if (Count == _lst.Count - 1)
            {
                Reset();
                return false;
            }

            Count++;
            return true;
        }

        public void Reset()
        {
            Count = -1;
        }

        public void SbFirmTypeCol()
        {
            _lst = new List<SbFirmType>();
        }
    }
}
