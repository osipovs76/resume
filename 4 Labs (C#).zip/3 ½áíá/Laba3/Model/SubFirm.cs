﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_v2.Model
{
    public class SubFirm
    {
        // поля контактной информации, список собственных контактов
        private string _bossName;
        private List<Contact> _conts;
        private string _email;
        private string _name;
        private string _ofcBossName;
        private string _tel;
        private SbFirmType _tpy;

        public string BossName { get => _bossName; set => _bossName = value; }
        public int CountCont { get => _conts.Count; }
        public string Email { get => _email; set => _email = value; }
        public bool IsMain { get; set; }
        public string Name { get => _name; set => _name = value; }
        public string OfcBossName { get => _ofcBossName; set => _ofcBossName = value; }
        public SbFirmType SbFirmTpy { get => _tpy; set => _tpy = value; }
        public string Tel { get => _tel; set => _tel = value; }

        public void AddCont(Contact newCont)
        {
            _conts.Add(newCont);
        }
        public bool ExistContact(Contact cont)
        {
            return _conts.Contains(cont);
        }

        public bool IsYourType(ContType type)
        {
            if (type.Name == _tpy.Name) return true;
            return false;
        }

        public SubFirm(string bossName, string email, string name, string ofcBossName, string tel, SbFirmType tpy, List<Contact> conts = null)
        {
            _bossName = bossName;
            _email = email;
            _name = name;
            _ofcBossName = ofcBossName;
            _tel = tel;
            _tpy = tpy;
            if (conts != null)
                _conts = conts;
            else
                _conts = new List<Contact>();
        }
    }
}
