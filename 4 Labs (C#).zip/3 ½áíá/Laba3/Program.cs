﻿using Lab_3_v2.Model;
using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Metadata.W3cXsd2001;

namespace Lab_3_v2
{
    class Program
    {
         

        static void Main(string[] args)
        {
            Console.WriteLine("Check tests");
            Console.ReadKey();

        }
    }
}
