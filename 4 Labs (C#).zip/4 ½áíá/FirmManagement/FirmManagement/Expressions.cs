﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class IntFieldExpr
	{
		private ILogExp _expr;
		public IntFieldExpr(ILogExp expression)
		{
			_expr = expression;
		}
		public bool Compare(string one, string two)
		{
			return _expr.Compare(one, two, "int");
		}
	}

	public class StringFieldExpr
	{
		private ILogExp _expr;
		public StringFieldExpr(ILogExp expression)
		{
			_expr = expression;
		}
		public bool Compare(string one, string two)
		{
			return _expr.Compare(one, two, "string");
		}
	}

	public class DateFieldExpr
	{
		private ILogExp _expr;
		public DateFieldExpr(ILogExp expression)
		{
			_expr = expression;
		}
		public bool Compare(string one, string two)
		{
			return _expr.Compare(one, two, "date");
		}
	}
}
