﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public abstract class Field
	{
		protected string _value;
		protected FilterRule _fRule;

		public abstract Field Clone();

		public abstract FilterRule CreateRule(ILogExp expression);

		public abstract string GetValue(Firm f);
	}


	public class NameField : Field
	{
		public override Field Clone()
		{
			NameField copy = new NameField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new NameRule(exp);
			return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._name;
		}
	}

	public class DateInField : Field
	{
		public override Field Clone()
		{
			DateInField copy = new DateInField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new DateInRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._dateIn;
		}
	}

	public class CountryField : Field
	{
		public override Field Clone()
		{
			CountryField copy = new CountryField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new CountryRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._country;
		}
	}

	public class PostInxField : Field
	{
		public override Field Clone()
		{
			PostInxField copy = new PostInxField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new PostInxRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._postInx;
		}
	}

	public class RegionField : Field
	{
		public override Field Clone()
		{
			RegionField copy = new RegionField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new RegionRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._region;
		}
	}

	public class TownField : Field
	{
		public override Field Clone()
		{
			TownField copy = new TownField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new TownRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._town;
		}
	}

	public class StreetField : Field
	{
		public override Field Clone()
		{
			StreetField copy = new StreetField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new StreetRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._street;
		}
	}

	public class WebField : Field
	{
		public override Field Clone()
		{
			WebField copy = new WebField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new WebRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._web;
		}
	}

	public class DateBegField : Field
	{
		public override Field Clone()
		{
			DateBegField copy = new DateBegField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new DateBegRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._dateBegin;
		}
	}

	public class ContactsCountField : Field
	{
		public override Field Clone()
		{
			ContactsCountField copy = new ContactsCountField();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new ContactsCountRule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._contactsCount;
		}
	}
	public class Field1 : Field
	{
		public override Field Clone()
		{
			Field1 copy = new Field1();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new Field1Rule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._field1;
		}
	}

	public class Field2 : Field
	{
		public override Field Clone()
		{
			Field2 copy = new Field2();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new Field2Rule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._field2;
		}
	}

	public class Field3 : Field
	{
		public override Field Clone()
		{
			Field3 copy = new Field3();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new Field3Rule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._field3;
		}
	}

	public class Field4 : Field
	{
		public override Field Clone()
		{
			Field4 copy = new Field4();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new Field4Rule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._field4;
		}
	}

	public class Field5 : Field
	{
		public override Field Clone()
		{
			Field5 copy = new Field5();
			copy._value = this._value;
			copy._fRule = this._fRule;
			return copy;
		}

		public override FilterRule CreateRule(ILogExp exp)
		{
			this._fRule = new Field5Rule(exp); return _fRule;
		}

		public override string GetValue(Firm f)
		{
			return f._field5;
		}
	}
}
