﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class FilterContr
	{
		private FirmMngr manager;
		private List<FilterRule> rules = new List<FilterRule>();

		public FirmMngr Manager
		{
			get => manager;
			set => manager = value;
		}

		public void Add(FilterRule r)
		{
			rules.Add(r);
		}
	}
}
