﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public abstract class FilterRule
	{
		public ILogExp Expression { get; set; }
		public abstract bool FirmRespond(Firm f, string value);
	}

	public class NameRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public NameRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._name, value);
		}
	}

	public class DateInRule : FilterRule
	{
		private DateFieldExpr dateFieldExpr;
		public DateInRule(ILogExp exp)
		{
			dateFieldExpr = new DateFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, String value)
		{
			return dateFieldExpr.Compare(f._dateIn, value);
		}
	}

	public class CountryRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public CountryRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._country, value);
		}
	}

	public class PostInxRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public PostInxRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._postInx, value);
		}
	}

	public class RegionRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public RegionRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._region, value);
		}
	}

	public class TownRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public TownRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._town, value);
		}
	}

	public class StreetRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public StreetRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._street, value);
		}
	}

	public class WebRule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public WebRule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._web, value);
		}
	}

	public class DateBegRule : FilterRule
	{
		private DateFieldExpr dateieldExpr;
		public DateBegRule(ILogExp exp)
		{
			dateieldExpr = new DateFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return dateieldExpr.Compare(f._dateBegin, value);
		}
	}

	public class ContactsCountRule : FilterRule
	{
		private IntFieldExpr intFieldExpr;
		public ContactsCountRule(ILogExp exp)
		{
			intFieldExpr = new IntFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return intFieldExpr.Compare(f._contactsCount, value);
		}
	}

	public class Field1Rule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public Field1Rule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._field1, value);
		}
	}

	public class Field2Rule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public Field2Rule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._field2, value);
		}
	}

	public class Field3Rule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public Field3Rule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._field3, value);
		}
	}

	public class Field4Rule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public Field4Rule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._field4, value);
		}
	}

	public class Field5Rule : FilterRule
	{
		private StringFieldExpr stringFieldExpr;
		public Field5Rule(ILogExp exp)
		{
			stringFieldExpr = new StringFieldExpr(exp);
		}

		public override bool FirmRespond(Firm f, string value)
		{
			return stringFieldExpr.Compare(f._field5, value);
		}
	}
}
