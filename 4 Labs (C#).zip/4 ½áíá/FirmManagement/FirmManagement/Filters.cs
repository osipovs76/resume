﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class ExpEQ : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			return one == two;
		}
	}

	public class ExpNoEQ : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			return one != two;
		}
	}

	public class ExpLT : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			if (type == "date")
			{
				char separator = '.';
				string[] oneArr = one.Split(separator);
				string[] twoArr = two.Split(separator);

				if (oneArr.Length != twoArr.Length || oneArr.Length != 3)
				{
					throw new Exception("Неправильный формат даты!");
				};

				if (Convert.ToInt32(oneArr[2]) < Convert.ToInt32(twoArr[2])) return true;
				else if (Convert.ToInt32(oneArr[2]) > Convert.ToInt32(twoArr[2])) return false;
				else if (Convert.ToInt32(oneArr[1]) < Convert.ToInt32(twoArr[1])) return true;
				else if (Convert.ToInt32(oneArr[1]) > Convert.ToInt32(twoArr[1])) return false;
				else if (Convert.ToInt32(oneArr[0]) < Convert.ToInt32(twoArr[0])) return true;
				else if (Convert.ToInt32(oneArr[0]) > Convert.ToInt32(twoArr[0])) return false;

				return false;
			}
			else if (type == "string")
			{
				return one.CompareTo(two) < 0;
			}
			else if (type == "int")
			{
				return Convert.ToInt32(one) < Convert.ToInt32(two);
			}
			else throw new Exception("Неправильный тип данных!");
		}
	}

	public class ExpGT : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			if (type == "date")
			{
				char separator = '.';
				string[] oneArr = one.Split(separator);
				string[] twoArr = two.Split(separator);

				if (oneArr.Length != twoArr.Length || oneArr.Length != 3)
				{
					throw new Exception("Неправильный формат даты!");
				};

				for (int i = 2; i >= 0; i--)
				{
					if (Convert.ToInt32(oneArr[2]) > Convert.ToInt32(twoArr[2])) return true;
					else if (Convert.ToInt32(oneArr[2]) < Convert.ToInt32(twoArr[2])) return false;
				}

				return false;
			}
			else if (type == "string")
			{
				return one.CompareTo(two) > 0;
			}
			else if (type == "int")
			{
				return Convert.ToInt32(one) > Convert.ToInt32(two);
			}
			else throw new Exception("Неправильный тип данных!");
		}
	}

	public class ExpContains : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			if (type == "string")
			{
				return one.Contains(two);
			}
			else throw new Exception("Неправильный тип данных!");
		}
	}

	public class ExpNoContains : ILogExp
	{
		public bool Compare(string one, string two, string type)
		{
			if (type == "string")
			{
				return !one.Contains(two);
			}
			else throw new Exception("Неправильный тип данных!");
		}
	}
}
