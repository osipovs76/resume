﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class Firm
	{
		public string _name;
		public string _dateIn;
		public string _country;
		public string _postInx;
		public string _region;
		public string _town;
		public string _street;
		public string _web;
		public string _dateBegin;
		public string _contactsCount;
		public string _field1;
		public string _field2;
		public string _field3;
		public string _field4;
		public string _field5;

		public Firm(string name, string dateIn, string country, string postInx,
			 string region, string town, string street, string web,
			 string dateBegin, string contactsCount, string field1 = null,
			 string field2 = null, string field3 = null, string field4 = null, string field5 = null)
		{
			_name = name;
			_dateIn = dateIn;
			_country = country;
			_postInx = postInx;
			_region = region;
			_town = town;
			_street = street;
			_web = web;
			_dateBegin = dateBegin;
			_contactsCount = contactsCount;
			_field1 = field1;
			_field2 = field2;
			_field3 = field3;
			_field4 = field4;
			_field5 = field5;
		}

		internal Firm Clone()
		{
			return new Firm(_name, _dateIn, _country, _postInx, _region, _town,
				 _street, _web, _dateBegin, _contactsCount, _field1, _field2,
				 _field3, _field4, _field5);
		}
	}
}
