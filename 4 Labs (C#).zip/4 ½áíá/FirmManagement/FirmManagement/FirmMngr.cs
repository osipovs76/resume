﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class FirmMngr
	{
		public List<Firm> firms { get; set; }
		public FirmVw firmView { get; set; }

		public Firm this[int index] { get => firms[index]; set => firms[index] = value; }

		public FirmMngr()
		{
			firmView = new FirmVw();
			firms = new List<Firm>();
		}
	}
}
