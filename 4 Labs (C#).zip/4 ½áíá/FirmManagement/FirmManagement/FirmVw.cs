﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class FirmVw
	{
		private List<Field> _fields;
		public List<Field> Fields { get => _fields; set => _fields = value; }

		public FirmVw()
		{
			_fields = new List<Field>();
			_fields.Add(new NameField());
			_fields.Add(new DateInField());
			_fields.Add(new CountryField());
			_fields.Add(new PostInxField());
			_fields.Add(new RegionField());
			_fields.Add(new TownField());
			_fields.Add(new StreetField());
			_fields.Add(new WebField());
			_fields.Add(new DateBegField());
			_fields.Add(new ContactsCountField());
			_fields.Add(new Field1());
			_fields.Add(new Field2());
			_fields.Add(new Field3());
			_fields.Add(new Field4());
			_fields.Add(new Field5());
		}
	}
}
