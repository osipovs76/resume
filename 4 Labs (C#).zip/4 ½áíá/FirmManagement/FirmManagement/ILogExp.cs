﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public interface ILogExp
	{
		bool Compare(string filter_value, string firm_value, string type);
	}
}
