﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class LogExpEnum : IEnumerator<ILogExp>
	{
		private List<ILogExp> logExps = new List<ILogExp>();
		int position = -1;
		int n;

		public ILogExp Current
		{
			get
			{
				if (position == -1 || position >= logExps.Count)
					throw new InvalidOperationException();
				return logExps[position];
			}
		}

		object IEnumerator.Current => throw new NotImplementedException();

		public bool MoveNext()
		{
			if (position < logExps.Count - 1)
			{
				position++;
				return true;
			}
			else
				return false;
		}

		public void Reset()
		{
			position = -1;
		}

		public void Dispose() { }

		public void Add(ILogExp exp)
		{
			logExps.Add(exp);
			n++;
		}

		public ILogExp this[int index] { get => logExps[index]; }
	}
}
