﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class LogExpFactory
	{
		private LogExpEnum expEnum = new LogExpEnum();

		public LogExpEnum ExpEnum { get => expEnum; }

		public void Create(string logExp)
		{
			switch (logExp)
			{
				case "=":
					expEnum.Add(new ExpEQ());
					break;
				case "!=":
					expEnum.Add(new ExpNoEQ());
					break;
				case "Содержит":
					expEnum.Add(new ExpContains());
					break;
				case "Не содержит":
					expEnum.Add(new ExpNoContains());
					break;
				case "<":
					expEnum.Add(new ExpLT());
					break;
				case ">":
					expEnum.Add(new ExpGT());
					break;
				case "-":
					expEnum.Add(null);
					break;
			}
		}
	}
}
