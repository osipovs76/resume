﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmManagement
{
	public class MainContr
	{
		private FirmMngr manager;
		public List<Firm> firms;

		public FirmMngr Manager => manager;
		public frmFilters CreateFormFilter()
		{
			manager = new FirmMngr();
			manager.firms = firms.Select(item => item.Clone()).ToList();

			FilterContr filterController = new FilterContr();
			filterController.Manager = manager;
			frmFilters form = new frmFilters();
			form.FilterController = filterController;
			return form;
		}

		public MainContr()
		{
			manager = new FirmMngr();

			firms = new List<Firm>();
			firms.Add(new Firm("KoreanSoft", "29.12.1998", "Корея", "301246",
					 "Азиатский", "Сеул", "", "ksoft.com", "",
					 "5"));

			manager.firms = firms.Select(item => item.Clone()).ToList();
		}
	}
}
