﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirmManagement
{
	public partial class frmAddFirm : Form
	{
		private frmCompStr strCompare;
		private frmCompVal valueCompare;
		public int n = 15;
		public string[] texts = new string[15];
		public frmAddFirm()
		{
			InitializeComponent();
			strCompare = new frmCompStr(n);
			valueCompare = new frmCompVal(n);

			for (int i = 0; i < n; i++)
			{
				Label label = strCompare.CreateLabel(i);
				label.Enabled = true;
				infoPanel.Controls.Add(label);
				TextBox textBox = valueCompare.CreateTextBox(i);
				textBox.Enabled = true;
				infoPanel.Controls.Add(textBox);
			}
		}

		private void applyBtn_Click(object sender, EventArgs e)
		{
			for (int i = 0; i < n; i++)
			{
				texts[i] = valueCompare.GetTextBox(i).Text;
			}

			this.Close();
		}
	}
}
