﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirmManagement
{
	public class frmCompStr
	{
		private int yChange = 40;
		private int yBegin = 30;
		private string[] fieldNames = {"Название", "Дата ввода", "Страна", "Индекс", "Регион",
				"Город", "Улица", "Web", "Дата начала", "Число контактов", "Field1", "Field2",
				"Field3", "Field4","Field5"};
		private Label[] labels;
		public frmCompStr(int n)
		{
			labels = new Label[n];
		}

		private Font labelFont = new Font("Sans Serif", 12, FontStyle.Bold);

		public Label CreateLabel(int i)
		{
			Label label = new Label();
			label.Font = labelFont;
			label.Text = fieldNames[i];
			label.Left = 20;
			label.Top = yChange * i + yBegin;
			label.Name = "label" + i;
			label.Enabled = false;
			label.AutoSize = true;
			labels[i] = label;
			return label;
		}

		public Label GetLabel(int i)
		{
			return labels[i];
		}
	}
}
