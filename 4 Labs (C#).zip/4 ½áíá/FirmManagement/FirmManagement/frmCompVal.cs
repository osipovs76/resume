﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirmManagement
{
	public class frmCompVal
	{

		private int yChange = 40;
		private int yBegin = 30;
		private int[] xPositions = { 190, 370, 430 };
		TextBox[] text_boxes;
		CheckBox[] check_boxes;
		Panel[] panels;
		RadioButton[,] rad_buttons;
		private Font stringFont = new Font("Sans Serif", 12, FontStyle.Regular);
		public frmCompVal(int n)
		{
			text_boxes = new TextBox[n];
			check_boxes = new CheckBox[n];
			panels = new Panel[n];
			rad_buttons = new RadioButton[n, 4];
		}

		public TextBox CreateTextBox(int i)
		{
			TextBox tb = new TextBox();
			tb.Height = 20;
			tb.Width = 140;
			tb.Left = xPositions[0];
			tb.Top = yChange * i + yBegin;
			tb.Name = "tb" + i;
			tb.Enabled = false;
			text_boxes[i] = tb;
			return tb;
		}

		public CheckBox CreateCheckBox(int i)
		{
			CheckBox cb = new CheckBox();
			cb.Text = "Нет";
			cb.Font = stringFont;
			cb.Left = xPositions[1];
			cb.Top = yChange * i + yBegin - 2;
			cb.Width = 60;
			cb.Checked = true;
			cb.Name = i.ToString();
			check_boxes[i] = cb;
			return cb;
		}

		public CheckBox GetCheckBox(int i)
		{
			return check_boxes[i];
		}

		public TextBox GetTextBox(int i)
		{
			return text_boxes[i];
		}

		public Panel GetPanel(int i)
		{
			return panels[i];
		}

		public RadioButton GetRadioButton(int i)
		{
			for (int j = 0; j < 4; j++)
			{
				if (rad_buttons[i, j].Checked)
					return rad_buttons[i, j];
			}
			return null;
		}

		public Panel CreatePanel(int i)
		{
			Panel p = new Panel();
			p.Left = xPositions[2];
			p.Top = yChange * i + yBegin - 2;
			p.Height = 30;
			p.Width = 350;

			rad_buttons[i, 0] = new RadioButton();
			rad_buttons[i, 0].Text = "=";
			rad_buttons[i, 0].Font = stringFont;
			rad_buttons[i, 0].Left = 10;
			rad_buttons[i, 0].Top = 0;
			rad_buttons[i, 0].Width = 50;
			rad_buttons[i, 0].Checked = true;

			rad_buttons[i, 1] = new RadioButton();
			rad_buttons[i, 1].Text = "!=";
			rad_buttons[i, 1].Font = stringFont;
			rad_buttons[i, 1].Left = 60;
			rad_buttons[i, 1].Top = 0;
			rad_buttons[i, 1].Width = 50;

			rad_buttons[i, 2] = new RadioButton();
			rad_buttons[i, 2].Font = stringFont;
			rad_buttons[i, 2].Left = 110;
			rad_buttons[i, 2].Top = 0;
			rad_buttons[i, 2].Width = 110;

			rad_buttons[i, 3] = new RadioButton();
			rad_buttons[i, 3].Font = stringFont;
			rad_buttons[i, 3].Left = 220;
			rad_buttons[i, 3].Top = 0;
			rad_buttons[i, 3].Width = 160;

			if (i == 1 || i == 8 || i == 9)
			{
				rad_buttons[i, 2].Text = "<";
				rad_buttons[i, 3].Text = ">";
			}
			else if (i >= 0)
			{
				rad_buttons[i, 2].Text = "Содержит";
				rad_buttons[i, 3].Text = "Не содержит";
			}

			for (int j = 0; j < 4; j++)
			{
				p.Controls.Add(rad_buttons[i, j]);
			}
			p.Enabled = false;
			panels[i] = p;
			return p;
		}
	}
}
