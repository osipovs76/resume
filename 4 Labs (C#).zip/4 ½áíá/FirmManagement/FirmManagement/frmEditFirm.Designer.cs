﻿namespace FirmManagement
{
	partial class frmEditFirm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.applyBtn = new System.Windows.Forms.Button();
			this.infoPanel = new System.Windows.Forms.Panel();
			this.SuspendLayout();
			// 
			// applyBtn
			// 
			this.applyBtn.Location = new System.Drawing.Point(152, 488);
			this.applyBtn.Name = "applyBtn";
			this.applyBtn.Size = new System.Drawing.Size(231, 64);
			this.applyBtn.TabIndex = 4;
			this.applyBtn.Text = "Применить";
			this.applyBtn.UseVisualStyleBackColor = true;
			this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
			// 
			// infoPanel
			// 
			this.infoPanel.AutoScroll = true;
			this.infoPanel.BackColor = System.Drawing.Color.White;
			this.infoPanel.Location = new System.Drawing.Point(13, 13);
			this.infoPanel.Margin = new System.Windows.Forms.Padding(4);
			this.infoPanel.Name = "infoPanel";
			this.infoPanel.Size = new System.Drawing.Size(496, 455);
			this.infoPanel.TabIndex = 3;
			// 
			// frmEditFirm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(523, 573);
			this.Controls.Add(this.applyBtn);
			this.Controls.Add(this.infoPanel);
			this.Name = "frmEditFirm";
			this.Text = "Редактировать фирму";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEditFirm_FormClosing);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button applyBtn;
		private System.Windows.Forms.Panel infoPanel;
	}
}