﻿namespace FirmManagement
{
	partial class frmFilters
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.filtersPanel = new System.Windows.Forms.Panel();
			this.applyBtn = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// filtersPanel
			// 
			this.filtersPanel.AutoScroll = true;
			this.filtersPanel.BackColor = System.Drawing.Color.White;
			this.filtersPanel.Location = new System.Drawing.Point(12, 12);
			this.filtersPanel.Name = "filtersPanel";
			this.filtersPanel.Size = new System.Drawing.Size(817, 410);
			this.filtersPanel.TabIndex = 8;
			// 
			// applyBtn
			// 
			this.applyBtn.Location = new System.Drawing.Point(325, 445);
			this.applyBtn.Name = "applyBtn";
			this.applyBtn.Size = new System.Drawing.Size(231, 64);
			this.applyBtn.TabIndex = 3;
			this.applyBtn.Text = "Применить";
			this.applyBtn.UseVisualStyleBackColor = true;
			this.applyBtn.Click += new System.EventHandler(this.applyBtn_Click);
			// 
			// frmFilters
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(845, 521);
			this.Controls.Add(this.applyBtn);
			this.Controls.Add(this.filtersPanel);
			this.Name = "frmFilters";
			this.Text = "Фильтры";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Panel filtersPanel;
		private System.Windows.Forms.Button applyBtn;
	}
}