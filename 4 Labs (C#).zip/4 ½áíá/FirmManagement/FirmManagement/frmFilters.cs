﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirmManagement
{
	public partial class frmFilters : Form
	{
		private FilterContr filterController;
		private frmCompStr strCompare;
		private frmCompVal valueCompare;
		public int n = 15;

		public FilterContr FilterController { get => filterController; set => filterController = value; }
		public frmCompStr StrCompare { get => strCompare; set => strCompare = value; }
		public frmCompVal ValueCompare { get => valueCompare; set => valueCompare = value; }
		public frmFilters()
		{
			InitializeComponent();
			strCompare = new frmCompStr(n);
			valueCompare = new frmCompVal(n);

			for (int i = 0; i < n; i++)
			{
				filtersPanel.Controls.Add(strCompare.CreateLabel(i));
				filtersPanel.Controls.Add(valueCompare.CreateTextBox(i));
				filtersPanel.Controls.Add(valueCompare.CreateCheckBox(i));
				filtersPanel.Controls.Add(valueCompare.CreatePanel(i));
				valueCompare.GetCheckBox(i).CheckedChanged += CheckedChanged;
			}
		}

		private void CheckedChanged(object sender, EventArgs e)
		{
			CheckBox checkBox = (CheckBox)sender;
			int i = Int32.Parse(checkBox.Name);
			valueCompare.GetTextBox(i).Enabled = checkBox.Checked ? false : true;
			strCompare.GetLabel(i).Enabled = checkBox.Checked ? false : true;
			valueCompare.GetPanel(i).Enabled = checkBox.Checked ? false : true;
		}

		public void HandleValues()
		{
			LogExpFactory factory = new LogExpFactory();
			List<string> conditions = new List<string>();
			for (int i = 0; i < n; i++)
			{
				if (valueCompare.GetTextBox(i).Text != "")
					conditions.Add(valueCompare.GetRadioButton(i).Text);
				else
					conditions.Add("-");
				factory.Create(conditions[i]);
			}
			List<Firm> firms = new List<Firm>();
			foreach (Firm f in filterController.Manager.firms)
			{
				int j = 0;
				for (int i = 0; i < n; i++)
				{
					FilterRule rule;
					if (factory.ExpEnum[i] != null)
					{
						rule = FilterController.Manager.firmView.Fields[i].CreateRule(factory.ExpEnum[i]);
						FilterController.Add(rule);
						string s = valueCompare.GetTextBox(i).Text;
						if (rule.FirmRespond(f, s))
							j++;
					}
					else j++;
				}
				if (j == n)
					firms.Add(f);
			}
			FilterController.Manager.firms = firms;
		}

		private void applyBtn_Click(object sender, EventArgs e)
		{
			HandleValues();
			this.Close();
		}
	}
}
