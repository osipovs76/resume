﻿namespace FirmManagement
{
	partial class frmMain
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "Нител",
            "30.11.2019",
            "Россия",
            "603137",
            "Нижегородская область",
            "Нижний Новгород",
            "Пр-кт Гагарина",
            "www.nitel.ru",
            "10.02.1200",
            "25",
            "8910324342443"}, -1, System.Drawing.Color.Empty, System.Drawing.Color.White, null);
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.filterBtn = new System.Windows.Forms.Button();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
			this.toolStripMenuItemName = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemDateIn = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemCountry = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemPostInx = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemRegion = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemTown = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemStreet = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemWeb = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemDateBeg = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemCountCont = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemField1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemField2 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemField3 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemField4 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItemField5 = new System.Windows.Forms.ToolStripMenuItem();
			this.addFirmBtn = new System.Windows.Forms.Button();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// listView1
			// 
			this.listView1.AllowColumnReorder = true;
			this.listView1.AllowDrop = true;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15});
			this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.listView1.ForeColor = System.Drawing.SystemColors.MenuText;
			this.listView1.FullRowSelect = true;
			this.listView1.GridLines = true;
			this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
			this.listView1.HideSelection = false;
			listViewItem1.StateImageIndex = 0;
			this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1});
			this.listView1.Location = new System.Drawing.Point(13, 31);
			this.listView1.Margin = new System.Windows.Forms.Padding(4);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(898, 376);
			this.listView1.TabIndex = 1;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.DoubleClick += new System.EventHandler(this.listView1_DoubleClick);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Название";
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Дата ввода";
			this.columnHeader2.Width = 119;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Text = "Страна";
			this.columnHeader3.Width = 86;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Индекс";
			this.columnHeader4.Width = 82;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Text = "Регион";
			this.columnHeader5.Width = 219;
			// 
			// columnHeader6
			// 
			this.columnHeader6.Text = "Город";
			this.columnHeader6.Width = 169;
			// 
			// columnHeader7
			// 
			this.columnHeader7.Text = "Улица";
			this.columnHeader7.Width = 172;
			// 
			// columnHeader8
			// 
			this.columnHeader8.Text = "Web";
			this.columnHeader8.Width = 148;
			// 
			// columnHeader9
			// 
			this.columnHeader9.Text = "Дата начала";
			this.columnHeader9.Width = 112;
			// 
			// columnHeader10
			// 
			this.columnHeader10.Text = "Число контактов";
			this.columnHeader10.Width = 161;
			// 
			// columnHeader11
			// 
			this.columnHeader11.Text = "Field 1";
			this.columnHeader11.Width = 147;
			// 
			// columnHeader12
			// 
			this.columnHeader12.Text = "Field 2";
			this.columnHeader12.Width = 147;
			// 
			// columnHeader13
			// 
			this.columnHeader13.Text = "Field 3";
			this.columnHeader13.Width = 147;
			// 
			// columnHeader14
			// 
			this.columnHeader14.Text = "Field 4";
			this.columnHeader14.Width = 147;
			// 
			// columnHeader15
			// 
			this.columnHeader15.Text = "Field 5";
			this.columnHeader15.Width = 147;
			// 
			// filterBtn
			// 
			this.filterBtn.Location = new System.Drawing.Point(595, 430);
			this.filterBtn.Name = "filterBtn";
			this.filterBtn.Size = new System.Drawing.Size(246, 65);
			this.filterBtn.TabIndex = 2;
			this.filterBtn.Text = "Фильтры";
			this.filterBtn.UseVisualStyleBackColor = true;
			this.filterBtn.Click += new System.EventHandler(this.filterBtn_Click);
			// 
			// toolStrip1
			// 
			this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton1});
			this.toolStrip1.Location = new System.Drawing.Point(0, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(918, 31);
			this.toolStrip1.TabIndex = 3;
			this.toolStrip1.Text = "toolStrip1";
			// 
			// toolStripDropDownButton1
			// 
			this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItemName,
            this.toolStripMenuItemDateIn,
            this.toolStripMenuItemCountry,
            this.toolStripMenuItemPostInx,
            this.toolStripMenuItemRegion,
            this.toolStripMenuItemTown,
            this.toolStripMenuItemStreet,
            this.toolStripMenuItemWeb,
            this.toolStripMenuItemDateBeg,
            this.toolStripMenuItemCountCont,
            this.toolStripMenuItemField1,
            this.toolStripMenuItemField2,
            this.toolStripMenuItemField3,
            this.toolStripMenuItemField4,
            this.toolStripMenuItemField5});
			this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
			this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
			this.toolStripDropDownButton1.Size = new System.Drawing.Size(14, 28);
			// 
			// toolStripMenuItemName
			// 
			this.toolStripMenuItemName.Checked = true;
			this.toolStripMenuItemName.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemName.Name = "toolStripMenuItemName";
			this.toolStripMenuItemName.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemName.Text = "Название";
			this.toolStripMenuItemName.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemName_CheckStateChanged);
			// 
			// toolStripMenuItemDateIn
			// 
			this.toolStripMenuItemDateIn.Checked = true;
			this.toolStripMenuItemDateIn.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemDateIn.Name = "toolStripMenuItemDateIn";
			this.toolStripMenuItemDateIn.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemDateIn.Text = "Дата ввода";
			this.toolStripMenuItemDateIn.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemDateIn_CheckStateChanged);
			// 
			// toolStripMenuItemCountry
			// 
			this.toolStripMenuItemCountry.Checked = true;
			this.toolStripMenuItemCountry.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemCountry.Name = "toolStripMenuItemCountry";
			this.toolStripMenuItemCountry.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemCountry.Text = "Страна";
			this.toolStripMenuItemCountry.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemCountry_CheckStateChanged);
			// 
			// toolStripMenuItemPostInx
			// 
			this.toolStripMenuItemPostInx.Checked = true;
			this.toolStripMenuItemPostInx.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemPostInx.Name = "toolStripMenuItemPostInx";
			this.toolStripMenuItemPostInx.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemPostInx.Text = "Индекс";
			this.toolStripMenuItemPostInx.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemPostInx_CheckStateChanged);
			// 
			// toolStripMenuItemRegion
			// 
			this.toolStripMenuItemRegion.Checked = true;
			this.toolStripMenuItemRegion.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemRegion.Name = "toolStripMenuItemRegion";
			this.toolStripMenuItemRegion.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemRegion.Text = "Регион";
			this.toolStripMenuItemRegion.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemRegion_CheckStateChanged);
			// 
			// toolStripMenuItemTown
			// 
			this.toolStripMenuItemTown.Checked = true;
			this.toolStripMenuItemTown.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemTown.Name = "toolStripMenuItemTown";
			this.toolStripMenuItemTown.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemTown.Text = "Город";
			this.toolStripMenuItemTown.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemTown_CheckStateChanged);
			// 
			// toolStripMenuItemStreet
			// 
			this.toolStripMenuItemStreet.Checked = true;
			this.toolStripMenuItemStreet.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemStreet.Name = "toolStripMenuItemStreet";
			this.toolStripMenuItemStreet.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemStreet.Text = "Улица";
			this.toolStripMenuItemStreet.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemStreet_CheckStateChanged);
			// 
			// toolStripMenuItemWeb
			// 
			this.toolStripMenuItemWeb.Checked = true;
			this.toolStripMenuItemWeb.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemWeb.Name = "toolStripMenuItemWeb";
			this.toolStripMenuItemWeb.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemWeb.Text = "WEB";
			this.toolStripMenuItemWeb.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemWeb_CheckStateChanged);
			// 
			// toolStripMenuItemDateBeg
			// 
			this.toolStripMenuItemDateBeg.Checked = true;
			this.toolStripMenuItemDateBeg.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemDateBeg.Name = "toolStripMenuItemDateBeg";
			this.toolStripMenuItemDateBeg.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemDateBeg.Text = "Дата начала";
			this.toolStripMenuItemDateBeg.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemDateBeg_CheckStateChanged);
			// 
			// toolStripMenuItemCountCont
			// 
			this.toolStripMenuItemCountCont.Checked = true;
			this.toolStripMenuItemCountCont.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemCountCont.Name = "toolStripMenuItemCountCont";
			this.toolStripMenuItemCountCont.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemCountCont.Text = "Число контактов";
			this.toolStripMenuItemCountCont.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemCountCont_CheckStateChanged);
			// 
			// toolStripMenuItemField1
			// 
			this.toolStripMenuItemField1.Checked = true;
			this.toolStripMenuItemField1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemField1.Name = "toolStripMenuItemField1";
			this.toolStripMenuItemField1.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemField1.Text = "Field 1";
			this.toolStripMenuItemField1.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemField1_CheckStateChanged);
			// 
			// toolStripMenuItemField2
			// 
			this.toolStripMenuItemField2.Checked = true;
			this.toolStripMenuItemField2.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemField2.Name = "toolStripMenuItemField2";
			this.toolStripMenuItemField2.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemField2.Text = "Field 2";
			this.toolStripMenuItemField2.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemField2_CheckStateChanged);
			// 
			// toolStripMenuItemField3
			// 
			this.toolStripMenuItemField3.Checked = true;
			this.toolStripMenuItemField3.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemField3.Name = "toolStripMenuItemField3";
			this.toolStripMenuItemField3.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemField3.Text = "Field 3";
			this.toolStripMenuItemField3.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemField3_CheckStateChanged);
			// 
			// toolStripMenuItemField4
			// 
			this.toolStripMenuItemField4.Checked = true;
			this.toolStripMenuItemField4.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemField4.Name = "toolStripMenuItemField4";
			this.toolStripMenuItemField4.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemField4.Text = "Field 4";
			this.toolStripMenuItemField4.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemField4_CheckStateChanged);
			// 
			// toolStripMenuItemField5
			// 
			this.toolStripMenuItemField5.Checked = true;
			this.toolStripMenuItemField5.CheckState = System.Windows.Forms.CheckState.Checked;
			this.toolStripMenuItemField5.Name = "toolStripMenuItemField5";
			this.toolStripMenuItemField5.Size = new System.Drawing.Size(224, 26);
			this.toolStripMenuItemField5.Text = "Field 5";
			this.toolStripMenuItemField5.CheckStateChanged += new System.EventHandler(this.toolStripMenuItemField5_CheckStateChanged);
			// 
			// addFirmBtn
			// 
			this.addFirmBtn.Location = new System.Drawing.Point(150, 430);
			this.addFirmBtn.Name = "addFirmBtn";
			this.addFirmBtn.Size = new System.Drawing.Size(246, 65);
			this.addFirmBtn.TabIndex = 4;
			this.addFirmBtn.Text = "Добавить фирму";
			this.addFirmBtn.UseVisualStyleBackColor = true;
			this.addFirmBtn.Click += new System.EventHandler(this.addFirmBtn_Click);
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(918, 523);
			this.Controls.Add(this.addFirmBtn);
			this.Controls.Add(this.toolStrip1);
			this.Controls.Add(this.filterBtn);
			this.Controls.Add(this.listView1);
			this.Name = "frmMain";
			this.Text = "Фирмы";
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ColumnHeader columnHeader6;
		private System.Windows.Forms.ColumnHeader columnHeader7;
		private System.Windows.Forms.ColumnHeader columnHeader8;
		private System.Windows.Forms.ColumnHeader columnHeader9;
		private System.Windows.Forms.ColumnHeader columnHeader10;
		private System.Windows.Forms.ColumnHeader columnHeader11;
		private System.Windows.Forms.ColumnHeader columnHeader12;
		private System.Windows.Forms.ColumnHeader columnHeader13;
		private System.Windows.Forms.ColumnHeader columnHeader14;
		private System.Windows.Forms.ColumnHeader columnHeader15;
		private System.Windows.Forms.Button filterBtn;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemName;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemDateIn;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemCountry;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemPostInx;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemRegion;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemTown;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemStreet;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemWeb;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemDateBeg;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemCountCont;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemField1;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemField2;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemField3;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemField4;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemField5;
		private System.Windows.Forms.Button addFirmBtn;
	}
}

