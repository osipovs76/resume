﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirmManagement
{
	public partial class frmMain : Form
	{
		private frmEditFirm formEditFirm;
		public frmAddFirm formAddFirm = new frmAddFirm();
		public MainContr mainContr;

		public frmMain()
		{
			InitializeComponent();

			mainContr = new MainContr();
			Apply(null, null);
		}

		private void Apply(object sender, EventArgs e)
		{
			listView1.Items.Clear();
			FirmVw view = mainContr.Manager.firmView;
			foreach (Firm firm in mainContr.Manager.firms)
			{
				List<string> s = new List<string>();
				foreach (Field field in view.Fields)
					s.Add(field.GetValue(firm));
				listView1.Items.Add(new ListViewItem(s.ToArray()));
			}
			listView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
		}

		private void AddFirm(object sender, EventArgs e)
		{
			Firm newFirm = new Firm(formAddFirm.texts[0], formAddFirm.texts[1],
				 formAddFirm.texts[2], formAddFirm.texts[3], formAddFirm.texts[4],
				 formAddFirm.texts[5], formAddFirm.texts[6], formAddFirm.texts[7],
				 formAddFirm.texts[8], formAddFirm.texts[9], formAddFirm.texts[10]);
			mainContr.Manager.firms.Add(newFirm);
			mainContr.firms.Add(newFirm);
			Apply(null, null);
		}

		private void ChangeView(object toolStripMenuItem, int columnIndex)
		{
			ToolStripMenuItem ts = (ToolStripMenuItem)toolStripMenuItem;
			CheckState state = ts.CheckState;
			bool st = state.ToString() == "Checked" ? true : false;
			if (st)
				listView1.Columns[columnIndex].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
			else
				listView1.Columns[columnIndex].Width = 0;
		}

		private void filterBtn_Click(object sender, EventArgs e)
		{
			frmFilters f = mainContr.CreateFormFilter();
			f.Show();
			f.FormClosed += new FormClosedEventHandler(Apply);
		}

		private void toolStripMenuItemName_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 0);
		}

		private void toolStripMenuItemDateIn_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 1);
		}

		private void toolStripMenuItemCountry_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 2);
		}

		private void toolStripMenuItemPostInx_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 3);
		}

		private void toolStripMenuItemRegion_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 4);
		}

		private void toolStripMenuItemTown_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 5);
		}

		private void toolStripMenuItemStreet_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 6);
		}

		private void toolStripMenuItemWeb_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 7);
		}

		private void toolStripMenuItemDateBeg_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 8);
		}

		private void toolStripMenuItemCountCont_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 9);
		}

		private void toolStripMenuItemField1_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 10);
		}

		private void toolStripMenuItemField2_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 11);
		}

		private void toolStripMenuItemField3_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 12);
		}

		private void toolStripMenuItemField4_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 13);
		}

		private void toolStripMenuItemField5_CheckStateChanged(object sender, EventArgs e)
		{
			ChangeView(sender, 14);
		}

		private void listView1_DoubleClick(object sender, EventArgs e)
		{
			ListView lv = (ListView)sender;
			if (lv.SelectedItems == null)
				return;

			string firmName = lv.SelectedItems[0].Text;
			Firm firm = null;

			foreach (Firm f in mainContr.Manager.firms)
			{
				if (f._name == firmName)
					firm = f;
			}

			if (firm == null)
				return;

			formEditFirm = new frmEditFirm(firm);
			formEditFirm.Show();
			formEditFirm.FormClosing += new FormClosingEventHandler(EditFirm);
		}

		private void EditFirm(object sender, EventArgs e)
		{
			frmEditFirm editForm = (frmEditFirm)sender;
			string[] values = editForm.texts;
			Firm editedFirm = new Firm(values[0], values[1], values[2], values[3],
				 values[4], values[5], values[6], values[7], values[8], values[9], values[10],
				 values[11], values[12], values[13], values[14]);
			int firmIndex = mainContr.Manager.firms.IndexOf(editForm.firmToEdit);
			int firmIndexinCol = mainContr.Manager.firms.IndexOf(editForm.firmToEdit);
			mainContr.Manager.firms[firmIndex] = editedFirm;
			mainContr.firms[firmIndexinCol] = editedFirm;
			Apply(null, null);
		}

		private void addFirmBtn_Click(object sender, EventArgs e)
		{
			formAddFirm = new frmAddFirm();
			formAddFirm.Show();
			formAddFirm.FormClosing += new FormClosingEventHandler(AddFirm);
		}
	}
}
