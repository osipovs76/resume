
package classes;

import java.awt.Graphics;
import java.awt.Rectangle;


public interface Entity_2 {
    public void tick();
    public void render(Graphics g);
     public Rectangle getBounds();
    
    public double getY();
    public double getX();
    
}
