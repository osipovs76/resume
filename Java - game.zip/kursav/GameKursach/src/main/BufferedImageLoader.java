package main;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
//класс для загрузки буферизованных изображений
public class BufferedImageLoader {
    
    private BufferedImage image;
    /*Создаем метод для загрузки изображения, в параметрах конструктора класса 
    File мы должны указать путь до файла После этого в объекта image у нас 
    будет храниться вся картинка, которую мы открыли*/
    
    public BufferedImage loadImage(String path) throws IOException{
        File file = new File(path);
        image = ImageIO.read(new File(path));
        return image;
    }
    
}
