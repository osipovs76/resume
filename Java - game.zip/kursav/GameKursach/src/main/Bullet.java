package main;

import classes.Entity_1;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;


public class Bullet extends GameObject implements Entity_1 {
    
    
    private Textures texture;
    private Game game;
    
    public Bullet(double x,double y,Textures texture,Game game){
        super(x,y);//супер классом здесь является унаследованные переменные из класса GameObject
        this.texture=texture;
        this.game=game;
        
    }
    public void tick(){
        y-=10;//Скорость пули
        
       
    }
    /*Задаем прямоугольную область для определения столкновения объекта*/
    @Override
    public Rectangle getBounds(){
        return new Rectangle((int)x,(int)y,32,32);
    }
     /*устанавливаем картинку для пули */
    @Override
    public void render(Graphics g){
        g.drawImage(texture.missile,(int)x,(int) y,null);
    }
    /*Получает значение x*/
    @Override
    public double getY(){
        return y;
    }
    /*Получает значение y*/
    @Override
    public double getX(){
        return x;
    }
    
}
