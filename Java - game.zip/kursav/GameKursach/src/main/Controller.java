package main;

import classes.Entity_1;
import classes.Entity_2;
import java.awt.Graphics;
import java.util.LinkedList;
import java.util.Random;


public class Controller {
    //создаем двусвязный списк в угловых скобках  указан тип хранимых значений 
    private LinkedList<Entity_1> e1=new LinkedList<Entity_1>();
    private LinkedList<Entity_2> e2=new LinkedList<Entity_2>();
   
     
     Textures texture;
     Random r=new Random();
     Entity_1 ent1;
     Entity_2 ent2;
     private Game game;

   public Controller(Textures texture,Game game) {
       this.texture=texture;
       this.game=game;
    }
     /*Метод для спавна врагов по всей длине фрейма по оси x и немного за видимой
   частью окна по оси y*/
    public void creatEnemy(int enemy_count){
        for(int i=0;i<enemy_count;i++){
            addEntity(new Enemy(r.nextInt(640),-10,texture,this,game));
        }
    }
     /*Метод отвечает за обновления в игре*/
    public void tick(){
        // Дружественные объекты
        for(int i=0;i<e1.size();i++){
            ent1=e1.get(i);
            
            ent1.tick();
        }
        
        // Вражеские объекты
        for(int i=0;i<e2.size();i++){
            ent2=e2.get(i);
            
            ent2.tick();
        }
        
    }
    /*Метод отвечает за отображение в игре*/
    public void render(Graphics g){
        //Дружественные объекты
        for(int i=0;i<e1.size();i++){
            ent1=e1.get(i);
            
            ent1.render(g);
        }
        
        //Вражеские объекты
        for(int i=0;i<e2.size();i++){
            ent2=e2.get(i);
            
            ent2.render(g);
        }
    }
    //метод в котором добавляется объект в двусвязный списк 1 сущности
    public void addEntity(Entity_1 block){
        e1.add(block);
    }
    //метод в котором удаляется объект из двусвязного списка 1 сущности
    public void removeEntity(Entity_1 block){
        e1.remove(block);
    }
    //метод в котором добавляется объект в двусвязный списк 2 сущности
     public void addEntity(Entity_2 block){
        e2.add(block);
    }
     //метод в котором удаляется объект из двусвязного списка 1 сущности
    public void removeEntity(Entity_2 block){
        e2.remove(block);
    }
    public LinkedList<Entity_1>getEntity_1(){
        return e1;
    }
    public LinkedList<Entity_2>getEntity_2(){
        return e2;
    }  
}
