
package main;

import classes.Entity_1;
import classes.Entity_2;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;


public class Enemy extends GameObject implements Entity_2 {
    Random r=new Random();
    private Textures texture;
    private Game game;
    private Controller c;
   
    private int speed=r.nextInt(3)+1;//рандомная скорость
    
    public Enemy(double x,double y,Textures texture,Controller c,Game game){
        super(x,y);//супер классом здесь является унаследованные переменные из класса GameObject
        this.texture=texture;
        this.c=c;
        this.game=game;
    }
    /*Метод отвечает за обновления в игре*/
    @Override
    public void tick(){
        y+=speed;
        //если выйдет по оси y за границы фрейма то вернет его на координаату -10
        if(y>Game.HEIGHT*Game.SCALE){
            x=r.nextInt(640);
            y=-10;
        }
        
        for(int i=0;i<game.e1.size();i++){
            Entity_1 tempEnt =game.e1.get(i);
            
             if(Physics.Collision(this, tempEnt)){
                c.removeEntity(tempEnt);//удаляет пулю
                c.removeEntity(this);//удаялет врага
                game.setenemy_killed(game.getenemy_killed()+1);
       }
        }
        
      
    }
    /*Метод отвечает за отображение врагов в игре*/
    @Override
    public void render(Graphics g){
        g.drawImage(texture.enemy,(int)x,(int)y,null);
    }
    /*Задаем прямоугольную область*/
    @Override
   public Rectangle getBounds(){
        return new Rectangle((int)x,(int)y,32,32);
    }
/*Получает значение x*/
    @Override
    public double getX() {
        return x;
    }

    /*Получает значение y*/
    @Override
    public double getY() {
        return y;
    }

    
}
