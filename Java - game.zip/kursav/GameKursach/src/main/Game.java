package main;
import classes.Entity_1;
import classes.Entity_2;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Taskbar.State;
import java.awt.event.KeyEvent;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
/*наследуем класс Game от класса Canvas, чтобы можно было создать холст который в методе
 main будет добавлен на фрейм и отображен на экране*/
public class Game extends Canvas implements Runnable { 
  public static final int WIDHT=320;// создаем переменную для для обозначения ширины которую нельзя будет поменять  
  public static final int HEIGHT=WIDHT/12*9;// создаем переменную для для обозначения высоты которую нельзя будет поменять
  public static final int SCALE=2;// эта переменная нужна как мастшабный которую нельзя будет поменять
  public String TITLE="2D SpacePlapformer";// переменная для названия игры 
  
  private boolean running=false;
  private Thread thread;// создаем новый поток 
  
  private BufferedImage image=new BufferedImage(WIDHT,HEIGHT,BufferedImage.TYPE_INT_RGB);
  private BufferedImage spriteSheet;// экземпляр для загрузки изображения со спрайтами
  private BufferedImage backround;//экземпляр для загрузки заднего фона
  
  private  boolean shooting=false;
  
  private int enemy_count=10;//количество врагов
  private int enemy_killed=0;//убитые враги
  
  private Player plr;
  private Controller controller;
  private Textures texture;
  public LinkedList<Entity_1>e1;
  public LinkedList<Entity_2>e2;
  public static int  HEALTH=100*2;
  public static enum STATE{//Состояние игры с помощью перечисления 
      MENU,GAME
  };
  private Menu menu;
  public static STATE state=STATE.MENU;// по умолчанию игра находиться в состоянии меню
  /*Метод для инициализации*/
  public void init(){
      requestFocus();//Устанавливаем фокус чтобы не нажимать мышкой на экран для начала игры
      BufferedImageLoader loader = new BufferedImageLoader();
        try{
            spriteSheet = loader.loadImage("resources/sheep-removebg-preview12.png");
            backround=loader.loadImage("resources/backgrond.png");
        }catch(IOException e){
        }
       
       texture=new Textures(this);
       
       controller=new Controller(texture,this);
       plr=new Player(200,200,texture,this,controller);
       menu=new Menu();
       
       e1=controller.getEntity_1();
       e2=controller.getEntity_2();
        
        this.addKeyListener(new KeyInput(this));
        this.addMouseListener(new MouseInput() );
        
       controller.creatEnemy(enemy_count);
  }
  
  
  
  /*Метод отвечающий за проверку, начат ли поток, ессли не начат то начинает его
  запуская метод run*/
  private synchronized void start(){
      if(running){
          return;
      }
      
      running=true;
      thread=new Thread(this);
      thread.start();
  }
 /*Метод отвечающий за проверку, начат ли поток, ессли  начат то меняет значение
  на falseи через метод join заставляет первый поток ждать окончания операций 
  второго*/
  private synchronized void stop(){
      if(!running){
          return;
      }
      
      running=false;
      try {
          thread.join();
      } catch (InterruptedException e) {
          Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, e);
      }
      System.exit(1);
  }
  //TEMP
  
  
  /*Метод run описывает основной цикл игры, в нем устанавливается определенное
  количество времени в течение которого игра обновляется и ограничивает 
  это самое время, а также рендерит графику */
  @Override
  public void run(){
      
      init();
      long lastTime=System.nanoTime();
      final double ammountOfTicks=60.0;
      double ns=1000000000/ammountOfTicks;
      double delta=0;
      while(running){
          long now=System.nanoTime();
          delta +=(now-lastTime)/ns;
          lastTime=now;
          if(delta >=1){
              tick();
              delta--;
          }
          render();
      }
      stop();
  }
  
  /*Метод отвечает за обновления в игре*/
  private void tick(){
      if(state==STATE.GAME){
         plr.tick();
         controller.tick();
      }
      
    /*если количество убитых врагов больше то к количеству врагов прибовляется 2,
      а количество убитых обнуляется и затем создается новые враги, которых с
      тало больше чем раньеш*/ 
      if (enemy_killed>=enemy_count){ 
          enemy_count+=2;
          enemy_killed=0;
          controller.creatEnemy(enemy_count);
      }
      
  }
  /*Этот метод отвечает за отображение  в игре.Использования класса  
  BufferStrategy нужна для создания двойной буферизации(тоесть 
  как бы происходит загрузка за кадром,при готовности которая будет отображена на фрейме)*/
  private void render(){
      BufferStrategy bs =this.getBufferStrategy();
      if(bs==null){
          createBufferStrategy(2);//Подгрузка за основынм экраном
          return;
      }
      Graphics g=bs.getDrawGraphics();//Создаем графический контекст для рисования буферов(вытягивает буферы)
      
      g.drawImage(image, 0, 0, getWidth(),getHeight(), this);
      g.fillRect(0, 0, 800, 800);
      g.drawImage(backround, 0, 0, this);
      if(state==STATE.GAME){
          plr.render(g);
          controller.render(g);
          
          g.setColor(Color.gray);
          g.fillRect(5, 5, 200, 50);
          
           g.setColor(Color.green);//создали здоровье
          g.fillRect(5, 5, HEALTH, 50);
          
           g.setColor(Color.white);
          g.drawRect(5, 5, 200, 50);
      }else if(state==STATE.MENU){
          menu.render(g);
      }
     texture=new Textures(this);
      g.dispose();
      bs.show();
  }
  /*Метод отвечающий за работу при нажатии клавиш*/
  public void keyPressed(KeyEvent e){
        int key=e.getKeyCode();
        
        if(state==STATE.GAME){
        
        if(key ==KeyEvent.VK_RIGHT ){
            plr.setVelX(5);
            
        }else if(key ==KeyEvent.VK_LEFT){
            plr.setVelX(-5);
            
        }else if(key==KeyEvent.VK_DOWN){
            plr.setVelY(5);
            
        }else if(key==KeyEvent.VK_UP){
            plr.setVelY(-5);
        }else if(key==KeyEvent.VK_SPACE && !shooting){
            shooting=true;//Зажимать нельзя
            controller.addEntity(new Bullet(plr.getX(),plr.getY(),texture,this));
        }
        }
    }
    /*Метод для отпускания клавиш*/
    public void keyReleased(KeyEvent e){
        int key=e.getKeyCode();
        
        if(key ==KeyEvent.VK_RIGHT ){
            plr.setVelX(0);
            
        }else if(key ==KeyEvent.VK_LEFT){
            plr.setVelX(0);
            
        }else if(key==KeyEvent.VK_DOWN){
            plr.setVelY(0);
            
        }else if(key==KeyEvent.VK_UP){
            plr.setVelY(0);
        }else if(key==KeyEvent.VK_SPACE){
            shooting=false;
        }
    }
  
  public static void main(String args[]){
      Game game=new Game();
      
      //С помощью класса Dimension инкапсулируем(сокрытая реализация класса) высоту и ширину
      game.setPreferredSize(new Dimension(WIDHT * SCALE,HEIGHT*SCALE));//Отступ внутри она от компонентов
      //game.setMaximumSize(new Dimension(WIDHT * SCALE,HEIGHT*SCALE));// этот метод нужен чтобы пользователь не увеличил окно больше заданноого размер( размер указан в скобках)
      //game.setMinimumSize(new Dimension(WIDHT * SCALE,HEIGHT*SCALE));//этот метод нужен чтобы пользователь не уменьшил окно меньше заданноого размер( размер указан в скобках)
      JFrame frame=new JFrame(game.TITLE);// создаем экземпляр класса Frame указывая в скобках как он будет называться фрейм с игрой
      frame.add(game);// добавляет экзмепляр класса Game на наш Frame (он отображает все в созданном фреме)
      frame.pack();//Метод pack определяет размер рамки таким образом, чтобы все ее содержимое соответствовало или превышало их предпочтительные размеры.
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//Метод чтобы при нажатии на крестик программа прекращала работу
      frame.setResizable(false);// запрещает менять размеры окна
      frame.setLocationRelativeTo(null);//окно центрируется на экране.
      frame.setVisible(true);// отображает окно на экране 
      
      game.start();//запускает игру
  }
  /*Получает спрайт*/
  public BufferedImage getSpriteSheet (){
      return spriteSheet;
  }
  /*Получает значение о количестве врагов*/
  public int getenemy_count(){
      return enemy_count;
  }
  /*Устанавливает количество врагов*/
  public void setenemy_count(int enemy_count){
      this.enemy_count=enemy_count;
  }
  /*Получает значение о количестве убитых врагов*/
public int getenemy_killed(){
    return enemy_killed;
}
/*Устанавливает значение о количестве убитых врагов*/
public void setenemy_killed(int enemy_killed){
    this.enemy_killed=enemy_killed;
}   
}