package main;
import java.awt.Rectangle;

public class GameObject {
    public double x,y;    //Координаты объекта
    public GameObject(double x,double y){
        this.x=x;
        this.y=y;
    }
    /*Метод котрый создает прямоугольник, является */
    public Rectangle getBounds(int width,int height){
        return new Rectangle((int)x,(int)y,width,height);
    }
}