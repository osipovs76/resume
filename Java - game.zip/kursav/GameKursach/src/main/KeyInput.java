package main;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
//Этот класс отвечает за отклик клавиатуры
public class KeyInput extends KeyAdapter {
    
    Game game;
    //вызываем ввод с клавиатуры в игровом классе Game
    public KeyInput(Game game){
        this.game=game;
    } 
    
    @Override
    public void keyPressed(KeyEvent e){
        game.keyPressed(e);
    }
    
    @Override
    public void keyReleased(KeyEvent e){
        game.keyReleased(e);
    }  
}