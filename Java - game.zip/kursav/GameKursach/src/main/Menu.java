package main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;


public class Menu {
    
    public Rectangle payButton=new Rectangle(280,150,100,50);//создали линии вокруг кнопки
    public Rectangle quitButton=new Rectangle(280,250,100,50);//создали линии вокруг кнопки
    
    /*Метод для создания кнопок в главном меню*/
    public void render(Graphics g){
        Graphics2D g2d=(Graphics2D) g;
        
        Font fnt1=new Font("arial",Font.BOLD,50);//Создаем шрифт
        g.setFont(fnt1);//устанавливаем шрифт
        g.setColor(Color.white);//устанавливаем цвет
        g.drawString("Space Platformer",150,100);//рисуем строку
        
        Font fnt2=new Font("aria",Font.BOLD,30);//Создаем шрифт
        g.setFont(fnt2);//устанавливаем шрифт
        g.drawString("Play", 299, 184);//рисуем строку
        g2d.draw(payButton);//устанавливаем линии
         g.drawString("Quit", 299, 284);//рисуем строку
        g2d.draw(quitButton);//устанавливаем линии
    }
}
