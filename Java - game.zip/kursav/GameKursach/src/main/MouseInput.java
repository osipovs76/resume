package main;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class MouseInput implements MouseListener {
    @Override
    public void mouseClicked(MouseEvent e) {
    }
    /*Метод вызывающийся при нажатии мыши на кнопку*/
    @Override
    public void mousePressed(MouseEvent e) {
        int mx=e.getX();//передает значение мыши по x
        int my=e.getY();//передает значение мыши по y

        //Play Button
        if(mx>=280 && mx<=380){//область нажатия по x 
            if(my>+150 && my<+180){//область нажатия по y
                //Нажимается кнопка запуска игры
                Game.state=Game.state.GAME;
            }
        }
         //Quit Button
        if(mx>=Game.WIDHT/2+120 && mx<=Game.WIDHT/2+220){ //область нажатия по x
            if(my>+250 && my<+280){ //область нажатия y
                //Нажимается кнопка выхода игры
                System.exit(1);
            }
        } 
    }
    @Override
    public void mouseReleased(MouseEvent e) {
    }
    @Override
    public void mouseEntered(MouseEvent e) {
    }
    @Override
    public void mouseExited(MouseEvent e) {
    } 
}
