
package main;

import classes.Entity_1;
import classes.Entity_2;

//Этот класс является реализацией столкновения
public class Physics {
    /*В методе столкновения в параметрах указывются 2 сущности - дружеская(ent1)
    и вражеская (ent2) если границы нашего ent1 пересекаются с границами ent2 то
    столкновение возвращает значение true если нет то false*/
    public static boolean Collision(Entity_1 ent1,Entity_2 ent2){
         if(ent1.getBounds().intersects(ent2.getBounds())){
            return true;
        }
        return false;
        
    }
    /*В методе столкновения в параметрах указывются 2 сущности - дружеская(ent1)
    и вражеская (ent2) если границы нашего ent2 пересекаются с границами ent1 то
    столкновение возвращает значение true если нет то false*/
    public static boolean Collision(Entity_2 ent2,Entity_1 ent1){
        if(ent2.getBounds().intersects(ent1.getBounds())){
           return true;
        }
        return false;
        
    }
}
