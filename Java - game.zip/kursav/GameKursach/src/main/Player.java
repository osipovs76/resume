
package main;

import classes.Entity_1;
import classes.Entity_2;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;


public class Player extends GameObject implements Entity_1{
    
    private double veocitylX=0;//Чтобы избавиться от задержек и добавить скорости и плавнсти передвижения 
    private double veocitylY=0;
    Game game;
    private Textures texture;
    Controller controller;
    
    public Player(double x,double y,Textures texture,Game game,Controller controller){
        super(x,y);//супер классом здесь является унаследованные переменные из класса GameObject
        this.texture=texture;
         this.game=game;
        this.controller=controller;
    }
    /*Метод отвечает за обновления игрока в игре*/
    public void tick(){
        x+=veocitylX;
        y+=veocitylY;
        
        //Задаем границы чтобы  игрок выходил за фрейм
        if(x<=0){
            x=0;
        }
        if(x>=640-32){
            x=640-32;
        }
        if(y<=0){
            y=0;
        }
        if(y>=480-32){
            y=480-32;
        }
        for(int i=0;i < game.e2.size();i++){
            Entity_2 tempent=game.e2.get(i);
            
            if(Physics.Collision(this, tempent)){// при столкновении уменьшает HEALTH
                controller.removeEntity(tempent);
                Game.HEALTH-=10;
                game.setenemy_killed(game.getenemy_killed()+1);
                if(Game.HEALTH<=0){
                   System.exit(1);
                }
            }
            
        }
    }
    /*Задаем прямоугольную область для определения столкновения объекта*/
    @Override
    public Rectangle getBounds(){
        return new Rectangle((int)x,(int)y,32,32);
    }
    /*устанавливаем картинку для игрока */
    @Override
    public void render(Graphics g){
        g.drawImage(texture.player, (int)x, (int)y, null);
    }
    /*Получает значение x*/
    @Override
    public double getX(){
        return x;
    }
    /*Получает значение y*/
    @Override
    public double getY(){
        return y;
    }
    public void setVelX(double velX){
        this.veocitylX=velX;
    }
    public void setVelY(double velY){
        this.veocitylY=velY;
    }
    
}
