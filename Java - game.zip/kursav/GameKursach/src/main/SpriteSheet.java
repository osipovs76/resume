package main;
import java.awt.image.BufferedImage;
public class SpriteSheet {
    private BufferedImage image;// обработка фотографий
 
    public SpriteSheet(BufferedImage image ){
        this.image=image;
    }
    /*создаем метод который будет захватывать изображение из спрайта со всеми картинками
    параметрами метода здесь являются col-столбец, row-строка, ширина и высота соответственно
    и возвращаем подизображение, определенное заданной прямоугольной областью*/
    
    public BufferedImage grabImage(int col,int row,int width,int height){
        BufferedImage img=image.getSubimage((col*32)-32, (row*32)-32, width, height);
        return img;
    }
}
