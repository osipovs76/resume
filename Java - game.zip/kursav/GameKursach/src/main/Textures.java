
package main;

import java.awt.image.BufferedImage;


public class Textures {
    
    public BufferedImage player,missile,enemy;
    
    private SpriteSheet ss;//экземпляр созданного класса SpriteSheet
    
     public Textures(Game game){
         ss=new SpriteSheet(game.getSpriteSheet());
         getTexture();
     }
     /*метод чтобы взяь картинки из подготовленного файла в ресурсах
     метод grabImage был прописанн в классе SpriteSheet чтобы вырезать определнную картинкуиз нее*/
     private void getTexture(){
         player=ss.grabImage(1, 1, 32,32);
         missile=ss.grabImage(2, 1, 32, 32);
         enemy=ss.grabImage(3, 1, 32, 32);
     } 
}
