package player.ai;
//Оценщик
public interface Evaluator {

    int eval(int[][] board,int player);

}