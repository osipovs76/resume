package player.ai;

import game.BoardHelper;

import java.awt.*;

public class Minimax {

    static int nodesExplored = 0;

    //возвращает ход с максимальным количеством очков
    public static Point solve(int[][] board, int player,int depth,Evaluator e){
        nodesExplored = 0;
        int bestScore = Integer.MIN_VALUE;
        Point bestMove = null;
        for(Point move : BoardHelper.getAllPossibleMoves(board,player)){
            //создаем новый узел
            int[][] newNode = BoardHelper.getNewBoardAfterMove(board,move,player);
            //рекурсивный вызов
            int childScore = minimax(newNode,player,depth-1,false,e);
            if(childScore > bestScore) {
                bestScore = childScore;
                bestMove = move;
            }
        }
        System.out.println("Исследованные узлы : " + nodesExplored);
        return bestMove;
    }



    //возвращает минимаксное значение для данного узла (без альфа-бета отсечения)

    private static int minimax(int[][] node, int player, int depth, boolean max, Evaluator e){
        //если достигнут конец игры или достигнут предел глубины, происходит оценка
        if(depth == 0 || BoardHelper.isGameFinished(node)){
            return e.eval(node,player);
        }
        int oplayer = (player==1) ? 2 : 1;
        //если ходов нет, то будем возвращать оценку следущей пожиции
        if((max && !BoardHelper.hasAnyMoves(node,player)) || (!max && !BoardHelper.hasAnyMoves(node,oplayer))){
            return minimax(node,player,depth-1,!max,e);
        }
        int score;
        if(max){
            //максимизация
            score = Integer.MIN_VALUE;
            for(Point move : BoardHelper.getAllPossibleMoves(node,player)){ //мой ход
                //создается новый узел
                int[][] newNode = BoardHelper.getNewBoardAfterMove(node,move,player);
                //рекурсивный вызов
                int childScore = minimax(newNode,player,depth-1,false,e);
                if(childScore > score) score = childScore;
            }
        }else{
            //минимизация
            score = Integer.MAX_VALUE;
            for(Point move : BoardHelper.getAllPossibleMoves(node,oplayer)){ //ход опонента
                //создается новый узел
                int[][] newNode = BoardHelper.getNewBoardAfterMove(node,move,oplayer);
                //рекурсивный вызов
                int childScore = minimax(newNode,player,depth-1,true,e);
                if(childScore < score) score = childScore;
            }
        }
        return score;
    }

    //возвращает минимаксное значение для данного узла с альфа-бетной обрезкой
    private static int alpha_beta_section(int[][] node,int player,int depth,boolean max,int alpha,int beta,Evaluator e){
        nodesExplored++;
        //если достигнут конец игры или достигнут предел глубины, оцените
        if(depth == 0 || BoardHelper.isGameFinished(node)){
            return e.eval(node,player);
        }
        int oplayer = (player==1) ? 2 : 1;
        //если ходов нет, то будем возвращать оценку следущей пожиции
        if((max && !BoardHelper.hasAnyMoves(node,player)) || (!max && !BoardHelper.hasAnyMoves(node,oplayer))){
            return alpha_beta_section(node,player,depth-1,!max,alpha,beta,e);
        }
        int score;
        if(max){
            //максимизация
            score = Integer.MIN_VALUE;
            for(Point move : BoardHelper.getAllPossibleMoves(node,player)){ //моя очередь
                //создается новый узел
                int[][] newNode = BoardHelper.getNewBoardAfterMove(node,move,player);
                //рекурсивный вызов
                int childScore = alpha_beta_section(newNode,player,depth-1,false,alpha,beta,e);
                if(childScore > score) score = childScore;
                //обновление альфы
                if(score > alpha) alpha = score;
                if(beta <= alpha) break; //Бета-отсечка
            }
        }else{
            //минимизация
            score = Integer.MAX_VALUE;
            for(Point move : BoardHelper.getAllPossibleMoves(node,oplayer)){ //ход опонента
                //создается новый узел
                int[][] newNode = BoardHelper.getNewBoardAfterMove(node,move,oplayer);
                //рекурсивный вызов
                int childScore = alpha_beta_section(newNode,player,depth-1,true,alpha,beta,e);
                if(childScore < score) score = childScore;
                //обновление беты
                if(score < beta) beta = score;
                if(beta <= alpha) break;//отсечка
            }
        }
        return score;
    }

}
